﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Notification;
using System.Text;

namespace Phone_Client
{
    public partial class MainPage : PhoneApplicationPage
    {
        HttpNotificationChannel channel;

        string channelName = "Usman's Channel";

        // Constructor
        public MainPage()
        {
            InitializeComponent();
            this.Loaded += MainPage_Loaded;
        }

        void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            channel = HttpNotificationChannel.Find(channelName);

            if (channel == null)
            {
                TogglSwitchNotificationChannel.IsChecked = false;
            }
            else
            {
                TogglSwitchNotificationChannel.IsChecked = true;
            }
        }

        private void ToggleSwitch_Tap(object sender, System.Windows.Input.GestureEventArgs e)
        {
            channel = HttpNotificationChannel.Find(channelName);

            if (channel != null)
            {
                channel.UnbindToShellToast();
                channel.UnbindToShellTile();
                channel.Close();
            }
            else
            {
                channel = new HttpNotificationChannel(channelName);
                channel.ShellToastNotificationReceived += channel_ShellToastNotificationReceived;
                channel.ChannelUriUpdated += channel_ChannelUriUpdated;
                channel.ErrorOccurred += channel_ErrorOccurred;

                ProgressBarPushNotifications.Visibility = System.Windows.Visibility.Visible;
                channel.Open();
                channel.BindToShellToast();
                channel.BindToShellTile();
            }
        }

        void channel_ErrorOccurred(object sender, NotificationChannelErrorEventArgs e)
        {
            Dispatcher.BeginInvoke(() =>
            {
                MessageBox.Show(e.Message, "Error", MessageBoxButton.OK);
                ProgressBarPushNotifications.Visibility = System.Windows.Visibility.Collapsed;
            });
        }

        void channel_ChannelUriUpdated(object sender, NotificationChannelUriEventArgs e)
        {
            Dispatcher.BeginInvoke(() =>
            {
                ProgressBarPushNotifications.Visibility = System.Windows.Visibility.Collapsed;
                MessageBox.Show(e.ChannelUri.ToString(), "Uri Recieved",MessageBoxButton.OK);
            });
        }

        void channel_ShellToastNotificationReceived(object sender, NotificationEventArgs e)
        {
            StringBuilder message = new StringBuilder();
            string relativeUri = string.Empty;

            message.AppendFormat("Received Toast {0}:\n", DateTime.Now.ToShortTimeString());

            // Parse out the information that was part of the message.
            foreach (string key in e.Collection.Keys)
            {
                message.AppendFormat("{0}: {1}\n", key, e.Collection[key]);
            }

            // Display a dialog of all the fields in the toast.
            Dispatcher.BeginInvoke(
                () => MessageBox.Show(message.ToString())
            );
        }
    }
}