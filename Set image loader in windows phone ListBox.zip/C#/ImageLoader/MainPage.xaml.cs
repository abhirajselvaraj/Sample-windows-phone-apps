﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;

namespace ImageLoader
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();
            ImageFile IMF = new ImageFile();
            List<ImageFile> lst = new List<ImageFile>();
            lst.Add(new ImageFile() { Imageurl = "http://kareninthekitchen.files.wordpress.com/2012/04/strawberry-shortcake10.jpg?r=" + System.DateTime.Now });
            lst.Add(new ImageFile() { Imageurl = "http://kareninthekitchen.files.wordpress.com/2012/04/strawberry-shortcake10.jpg?r=" + System.DateTime.Now });
            lst.Add(new ImageFile() { Imageurl = "http://kareninthekitchen.files.wordpress.com/2012/04/strawberry-shortcake10.jpg?r=" + System.DateTime.Now });
            lst.Add(new ImageFile() { Imageurl = "http://kareninthekitchen.files.wordpress.com/2012/04/strawberry-shortcake10.jpg?r=" + System.DateTime.Now });
            lst.Add(new ImageFile() { Imageurl = "http://kareninthekitchen.files.wordpress.com/2012/04/strawberry-shortcake10.jpg?r=" + System.DateTime.Now });
            lst.Add(new ImageFile() { Imageurl = "http://kareninthekitchen.files.wordpress.com/2012/04/strawberry-shortcake10.jpg?r=" + System.DateTime.Now });
            lst.Add(new ImageFile() { Imageurl = "http://kareninthekitchen.files.wordpress.com/2012/04/strawberry-shortcake10.jpg?r=" + System.DateTime.Now });
            lst.Add(new ImageFile() { Imageurl = "http://kareninthekitchen.files.wordpress.com/2012/04/strawberry-shortcake10.jpg?r=" + System.DateTime.Now });
            Listimg.ItemsSource = lst;
           
        }
    }
    public class ImageFile
    {
        public string Imageurl
        {
            get;
            set;
        }
    }
}